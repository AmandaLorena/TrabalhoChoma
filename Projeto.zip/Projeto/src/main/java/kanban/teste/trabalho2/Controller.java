package kanban.teste.trabalho2;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        // Usuário e senha padrão para testes
        String defaultUsername = "admin";
        String defaultPassword = "123456";

        if (defaultUsername.equals(loginRequest.getUsername()) &&
                defaultPassword.equals(loginRequest.getPassword())) {

            //